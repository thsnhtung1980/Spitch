package com.yourpackage.audiomodifier;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;

public class MainActivity extends Activity {
    private SeekBar pitchBar, tempoBar, eqBassBar, eqMidBar, eqTrebleBar;
    private TextView pitchValue, tempoValue, bassValue, midValue, trebleValue;
    private Button startButton, stopButton;
    public static float pitch = 1.0f;
    public static float tempo = 1.0f;
    public static short bassLevel = 0, midLevel = 0, trebleLevel = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        // Yêu cầu quyền runtime
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.MODIFY_AUDIO_SETTINGS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{
												  Manifest.permission.RECORD_AUDIO,
												  Manifest.permission.MODIFY_AUDIO_SETTINGS
											  }, 1);
        }

        // Khởi tạo các control
        pitchBar = findViewById(R.id.pitchBar);
        tempoBar = findViewById(R.id.tempoBar);
        eqBassBar = findViewById(R.id.eqBassBar);
        eqMidBar = findViewById(R.id.eqMidBar);
        eqTrebleBar = findViewById(R.id.eqTrebleBar);

        pitchValue = findViewById(R.id.pitchValue);
        tempoValue = findViewById(R.id.tempoValue);
        bassValue = findViewById(R.id.bassValue);
        midValue = findViewById(R.id.midValue);
        trebleValue = findViewById(R.id.trebleValue);

        startButton = findViewById(R.id.startButton);
        stopButton = findViewById(R.id.stopButton);

        // Thiết lập SeekBar listeners
        pitchBar.setMax(200); // 0.5x đến 2.5x
        pitchBar.setProgress(100);
        pitchBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					pitch = 0.5f + (progress / 100f) * 2f;
					pitchValue.setText(String.format("Pitch: %.2fx", pitch));
				}
				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {}
				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {}
			});

        tempoBar.setMax(200); // 0.5x đến 2.5x
        tempoBar.setProgress(100);
        tempoBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					tempo = 0.5f + (progress / 100f) * 2f;
					tempoValue.setText(String.format("Tempo: %.2fx", tempo));
				}
				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {}
				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {}
			});

        // EQ controls (-15dB to +15dB)
        setupEqBar(eqBassBar, bassValue, "Bass", (short)1500);
        setupEqBar(eqMidBar, midValue, "Mid", (short)1500);
        setupEqBar(eqTrebleBar, trebleValue, "Treble", (short)1500);

        startButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					startService(new Intent(MainActivity.this, AudioService.class));
				}
			});

        stopButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					stopService(new Intent(MainActivity.this, AudioService.class));
				}
			});
    }

    private void setupEqBar(SeekBar bar, TextView valueText, String label, short maxLevel) {
        bar.setMax(3000); // -15dB to +15dB
        bar.setProgress(1500);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					short level = (short)(progress - 1500);
					if (label.equals("Bass")) bassLevel = level;
					else if (label.equals("Mid")) midLevel = level;
					else trebleLevel = level;
					valueText.setText(String.format("%s: %ddB", label, level/100));
				}
				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {}
				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {}
			});
    }
}

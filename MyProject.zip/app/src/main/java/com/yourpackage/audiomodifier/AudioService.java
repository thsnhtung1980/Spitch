package com.yourpackage.audiomodifier;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.media.audiofx.Equalizer;
import android.media.AudioTrack;
import android.media.AudioRecord;
import android.media.AudioManager;
import android.media.AudioFormat;
import android.media.MediaRecorder;
import be.tarsos.dsp.AudioEvent;
import be.tarsos.dsp.AudioProcessor;
import be.tarsos.dsp.io.TarsosDSPAudioFormat;
import be.tarsos.dsp.pitch.PitchProcessor;
import be.tarsos.dsp.pitch.PitchDetectionHandler;
import be.tarsos.dsp.pitch.PitchDetectionResult;
import java.io.DataOutputStream;

public class AudioService extends Service {
    private AudioTrack audioTrack;
    private AudioRecord audioRecord;
    private Equalizer equalizer;
    private volatile boolean isRunning = false;
    private static final int SAMPLE_RATE = 44100;
    private static final int BUFFER_SIZE = 4096;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!isRunning) {
            // Kích hoạt remote submix bằng lệnh root
            executeRootCommand("setprop audio.r_submix.default 1");
            startAudioProcessing();
            isRunning = true;
        }
        return START_STICKY;
    }

    private void startAudioProcessing() {
        try {
            // Khởi tạo AudioTrack để phát âm thanh
            audioTrack = new AudioTrack(
                AudioManager.STREAM_MUSIC,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_16BIT,
                BUFFER_SIZE,
                AudioTrack.MODE_STREAM);

            // Khởi tạo AudioRecord để capture từ remote submix
            audioRecord = new AudioRecord(
                MediaRecorder.AudioSource.REMOTE_SUBMIX,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_STEREO,
                AudioFormat.ENCODING_PCM_16BIT,
                BUFFER_SIZE);

            // Kiểm tra trạng thái
            if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
                throw new IllegalStateException("AudioRecord initialization failed");
            }
            if (audioTrack.getState() != AudioTrack.STATE_INITIALIZED) {
                throw new IllegalStateException("AudioTrack initialization failed");
            }

            // Khởi tạo Equalizer
            equalizer = new Equalizer(0, audioTrack.getAudioSessionId());
            equalizer.setEnabled(true);

            // Khởi tạo PitchProcessor từ TarsosDSP
            final PitchProcessor pitchProcessor = new PitchProcessor(
                PitchProcessor.PitchEstimationAlgorithm.FFT_YIN,
                SAMPLE_RATE,
                BUFFER_SIZE,
                new PitchDetectionHandler() {
                    @Override
                    public void handlePitch(PitchDetectionResult pitchDetectionResult, AudioEvent audioEvent) {
                        // Cập nhật pitch từ MainActivity
                        float[] floatBuffer = audioEvent.getFloatBuffer();
                        // PitchProcessor sẽ tự động xử lý pitch, không cần thêm logic ở đây
                    }
                }
            );

            audioTrack.play();
            audioRecord.startRecording();

            // Thread xử lý audio
            new Thread(new Runnable() {
					@Override
					public void run() {
						android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO);
						byte[] buffer = new byte[BUFFER_SIZE];
						while (isRunning) {
							// Đọc từ submix
							int read = audioRecord.read(buffer, 0, BUFFER_SIZE);
							if (read > 0) {
								// Chuyển byte sang float cho TarsosDSP
								float[] floatBuffer = new float[read / 2];
								for (int i = 0; i < read / 2; i++) {
									floatBuffer[i] = ((buffer[i * 2] & 0xFF) | (buffer[i * 2 + 1] << 8)) / 32768.0f;
								}

								// Xử lý pitch
								TarsosDSPAudioFormat format = new TarsosDSPAudioFormat(SAMPLE_RATE, 16, 2, true, false);
								AudioEvent event = new AudioEvent(format);
								event.setFloatBuffer(floatBuffer);
								pitchProcessor.process(event);

								// Lấy buffer đã xử lý pitch
								float[] processedBuffer = event.getFloatBuffer();

								// Xử lý tempo (giả lập bằng cách điều chỉnh tốc độ playback)
								if (MainActivity.tempo != 1.0f) {
									float[] adjustedBuffer = adjustTempo(processedBuffer, MainActivity.tempo);
									processedBuffer = adjustedBuffer;
								}

								// Cập nhật EQ
								equalizer.setBandLevel((short)0, MainActivity.bassLevel);
								equalizer.setBandLevel((short)1, MainActivity.midLevel);
								equalizer.setBandLevel((short)2, MainActivity.trebleLevel);

								// Chuyển float buffer về byte để phát qua AudioTrack
								byte[] outputBuffer = new byte[processedBuffer.length * 2];
								for (int i = 0; i < processedBuffer.length; i++) {
									short val = (short) (processedBuffer[i] * 32767.0f);
									outputBuffer[i * 2] = (byte) (val & 0xFF);
									outputBuffer[i * 2 + 1] = (byte) ((val >> 8) & 0xFF);
								}

								// Viết ra AudioTrack
								audioTrack.write(outputBuffer, 0, outputBuffer.length);
							}
						}
					}
				}).start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private float[] adjustTempo(float[] input, float tempo) {
        int newLength = (int)(input.length / tempo);
        float[] output = new float[newLength];
        for (int i = 0; i < newLength; i++) {
            int srcIndex = (int)(i * tempo);
            if (srcIndex < input.length) {
                output[i] = input[srcIndex];
            }
        }
        return output;
    }

    private void executeRootCommand(String command) {
        try {
            Process process = Runtime.getRuntime().exec("su");
            DataOutputStream os = new DataOutputStream(process.getOutputStream());
            os.writeBytes(command + "\n");
            os.writeBytes("exit\n");
            os.flush();
            process.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        if (audioRecord != null) {
            audioRecord.stop();
            audioRecord.release();
        }
        if (audioTrack != null) {
            audioTrack.stop();
            audioTrack.release();
        }
        if (equalizer != null) {
            equalizer.release();
        }
    }
}
